"""
tools/import_workbooks.py - turns the two Excel workbooks into the JSON files the website reads.

    py tools/import_workbooks.py

Input  : docs/source_data/Numerology_Numbers_and_Formulas.xlsx and Vastu_Meter_ContentV1.xlsx
         (the original .xls files are kept next to them; the .xlsx copies are plain conversions made by
          opening the .xls in Excel/LibreOffice and choosing Save As .xlsx)
Output : data/numerology_workbook.json, data/vastu_meter.json, docs/DATA_COVERAGE.md

Every cell that is read is recorded. Any non-empty cell that is NOT imported is listed in the coverage report,
so nothing can be dropped silently. Source text is kept exactly as written (typos included, under "raw").
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "docs" / "source_data"
NUM_XLSX, VAS_XLSX = SRC / "Numerology_Numbers_and_Formulas.xlsx", SRC / "Vastu_Meter_ContentV1.xlsx"


class Reader:
    """Reads cells and remembers which ones were used."""
    def __init__(self, ws):
        self.ws, self.used = ws, set()

    def get(self, coord):
        self.used.add(coord)
        v = self.ws[coord].value
        return v.strip() if isinstance(v, str) else v

    def raw(self, coord):
        self.used.add(coord)
        return self.ws[coord].value

    def unused(self):
        out = []
        for row in self.ws.iter_rows():
            for c in row:
                if c.value is not None and c.coordinate not in self.used:
                    out.append((c.coordinate, str(c.value)[:70].replace("\n", " / ")))
        return out

    def nonempty(self):
        return sum(1 for row in self.ws.iter_rows() for c in row if c.value is not None)


# ----------------------------------------------------------------------------- Numerology
def import_numerology():
    wb = openpyxl.load_workbook(NUM_XLSX)
    out = {"source_file": "Numerology_Numbers_and_Formulas.xls", "sheets": {}}
    cover = {}

    # --- sheet "Numerology Table": 24 numbers with their formula text
    r = Reader(wb["Numerology Table"])
    rows = []
    for n in range(2, 26):
        rows.append({"no": r.get(f"A{n}"), "name": r.get(f"B{n}"), "also_called": r.get(f"C{n}") or "",
                     "formula": r.get(f"D{n}"), "cell_range": f"A{n}:D{n}"})
    for c in "ABCD":
        r.get(f"{c}1")
    out["sheets"]["Numerology Table"] = {"purpose": "Overview of 24 numerology numbers and how each is calculated", "rows": rows}
    cover["Numerology Table"] = r

    # --- sheet "Sheet2": the 20 'core numbers' with worked examples
    r = Reader(wb["Sheet2"])
    core = []
    for row in range(1, 80):
        d = r.ws[f"D{row}"].value
        if isinstance(d, int):
            core.append({"no": r.get(f"D{row}"), "title": r.get(f"E{row}"), "based_on": r.get(f"F{row}") or "",
                         "describes": r.get(f"G{row}") or "", "example": r.get(f"H{row}") or "",
                         "notes": r.get(f"I{row}") or "", "source_row": row})
    r.get("D7")
    out["sheets"]["Sheet2"] = {"purpose": "Core numbers: what each is based on, what it describes, and a worked example", "core_numbers": core}
    cover["Sheet2"] = r

    # --- sheet "Sheet1": tables
    r = Reader(wb["Sheet1"])
    s1 = {"purpose": "Letter-value tables, vowel table, combination matrix, life-period / pinnacle / challenge tables, "
                     "essence-number worked table and transit letters"}
    # Chaldean: numbers in D8:K8, letters under them
    chal = {}
    for col in "DEFGHIJK":
        num = r.get(f"{col}8")
        for row in (10, 12, 14, 16, 18):
            ch = r.get(f"{col}{row}")
            if ch:
                chal[ch.upper()] = num
    r.get("C8")
    s1["chaldean"] = {"values": dict(sorted(chal.items())), "cells": "C8:K18"}
    pyth = {}
    for col in "DEFGHIJKL":
        num = r.get(f"{col}25")
        for row in (27, 29, 31):
            ch = r.get(f"{col}{row}")
            if ch:
                pyth[ch.upper()] = num
    r.get("C24")
    s1["pythagorean"] = {"values": dict(sorted(pyth.items())), "cells": "C24:L31"}
    vowel = {}
    for col in "DEFGHIJKL":
        num = r.get(f"{col}47")
        t = r.get(f"{col}49")
        if t:
            for ch in re.split(r"&", t):
                vowel[ch.strip().upper()] = num
    r.get("C47")
    s1["vowel_values"] = {"values": vowel, "note": r.get("D51"), "cells": "C47:L51"}
    s1["intensified_absence_reference"] = {
        "groups": [r.get(f"{c}34") for c in "DEFGHIJKL"], "row36_raw": [r.get(f"{c}36") for c in "DEFGHIJKL"],
        "label": r.get("C34"), "cells": "C34:L36"}
    s1["essence_year_header"] = [r.get(f"{c}38") for c in "DEFGHIJKL"]
    r.get("C38")
    # combination matrix
    heads = [r.get(f"{c}59") for c in "EFGHIJKLMNOP"]
    matrix = {}
    labels = [r.get(f"D{row}") for row in range(60, 72)]
    for i, row in enumerate(range(60, 72)):
        for j, col in enumerate("EFGHIJKLMNOP"):
            v = r.raw(f"{col}{row}") if r.ws[f"{col}{row}"].value is not None else None
            if v is not None:
                matrix[f"{labels[i]}-{heads[j]}"] = str(v).strip()
    s1["combination_matrix"] = {"title": r.get("D57"), "numbers": heads, "cells": matrix,
                                "cell_range": "D57:P71", "legend_in_source": None}
    # life period phases
    life = []
    for row in range(80, 97, 2):
        life.append({"life_path": r.get(f"C{row}"), "p1_start": r.get(f"D{row}"), "p1_end": r.get(f"E{row}"),
                     "p2_start": r.get(f"G{row}"), "p2_end": r.get(f"H{row}"), "p3_raw": r.get(f"J{row}"),
                     "significance": r.get(f"M{row}"), "source_row": row})
    s1["life_period"] = {"title": r.get("C74"), "headers": {"p1": r.get("D76"), "p1_sub": r.get("D77"), "p2": r.get("G76"),
                         "p2_sub": r.get("G77"), "p3": r.get("J76"), "p3_sub": r.get("J77"), "month_col": r.get("D79"),
                         "day_col": r.get("G79"), "year_col": r.get("J79"), "sig_col": r.get("M79"), "lp_col": r.get("C76")},
                         "rows": life}
    # pinnacle table
    pin = []
    for row in range(106, 123, 2):
        pin.append({"life_path": r.get(f"C{row}"), "p1_start": r.get(f"D{row}"), "p1_end": r.get(f"E{row}"),
                    "p2_start": r.get(f"G{row}"), "p2_end": r.get(f"H{row}"), "p3_start": r.get(f"J{row}"),
                    "p3_end": r.get(f"K{row}"), "p4_start": r.get(f"M{row}"), "significance": r.get(f"S{row}"), "source_row": row})
    s1["pinnacle_table"] = {"title": r.get("C102"), "headers": [r.get("D102"), r.get("G102"), r.get("J102"), r.get("M102")],
                            "season_notes": [r.get("D103"), r.get("G103"), r.get("J103"), r.get("M103")],
                            "basis": [r.get("D105"), r.get("G105"), r.get("J105"), r.get("M105")],
                            "lp_header": r.get("C104"), "sig_header": r.get("S105"), "rows": pin}
    themes = {}
    for row in range(106, 115):
        themes[str(r.get(f"X{row}"))] = r.get(f"Y{row}")
    r.get("X105"), r.get("Y105")
    s1["challenge_themes"] = themes
    # essence worked example
    ess = {"name": r.get("C125"), "essence_title": r.get("D125"), "dob": r.ws["C126"].value.date().isoformat(),
           "headers": [r.get(f"{c}126") for c in "DEFGHIJKL"], "rows": []}
    r.used.add("C126")
    for row in range(127, 201):
        ess["rows"].append({"year": r.ws[f"D{row}"].value if not str(r.ws[f"D{row}"].value).startswith("=") else None,
                            "first_letter": r.get(f"F{row}"), "first_value": r.get(f"G{row}"),
                            "last_letter": r.get(f"J{row}"), "last_value": r.get(f"K{row}")})
        for c in "DELM":
            r.get(f"{c}{row}")
    s1["essence_example"] = ess
    # transit letters
    tr = []
    for row in range(206, 223, 2):
        tr.append({"number_label": r.get(f"C{row}"), "letters": r.get(f"D{row}"), "significance": r.get(f"E{row}")})
    s1["transit_letters"] = {"headers": [r.get("C205"), r.get("D205"), r.get("E205")], "rows": tr}
    out["sheets"]["Sheet1"] = s1
    cover["Sheet1"] = r
    return out, cover


# ----------------------------------------------------------------------------- Vastu
LABEL_MAP = {
    "veryauspicious": "Very Auspicious", "highlyauspicious": "Highly Auspicious", "highlyasupicious": "Highly Auspicious",
    "auspicious": "Auspicious", "canbebetter": "Can Be Better", "inauspicious": "Inauspicious",
    "inasupicious": "Inauspicious", "inaupicious": "Inauspicious", "highlyinauspicious": "Highly Inauspicious",
    "highlyinasupicious": "Highly Inauspicious", "higlyinauspicious": "Highly Inauspicious"}
DIRS = {"NE": ("NE", "North-East"), "East": ("E", "East"), "SE": ("SE", "South-East"), "North": ("N", "North"),
        "BrahmAsthaan": ("BR", "Brahmasthan (centre)"), "South": ("S", "South"), "NW": ("NW", "North-West"),
        "West": ("W", "West"), "SW": ("SW", "South-West")}


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def import_vastu():
    wb = openpyxl.load_workbook(VAS_XLSX)
    out = {"source_file": "Vastu_Meter_ContentV1.xls", "directions": {v[0]: v[1] for v in DIRS.values()},
           "label_variants_normalised": {}, "elements": []}
    cover = {}
    for ws in wb.worksheets:
        r = Reader(ws)
        titles = [row for row in range(1, ws.max_row + 1)
                  if isinstance(ws[f"F{row}"].value, str) and ws[f"F{row}"].value.startswith("Which Should be the Direction of")]
        for t in titles:
            title = r.get(f"F{t}")
            name = title.replace("Which Should be the Direction of", "").strip()
            cells = {}
            for off_label, off_name, off_score, cols in ((1, 2, 4, "FJN"), (6, 7, 9, "FJN"), (11, 12, 14, "FJN")):
                for col in cols:
                    dname = r.get(f"{col}{t + off_name}")
                    if dname is None:
                        continue
                    code, full = DIRS[dname]
                    lab_raw = r.raw(f"{col}{t + off_label}")
                    score = r.get(f"{col}{t + off_score}")
                    entry = {"direction": code, "direction_name": full, "source_name": dname,
                             "cells": f"{col}{t + off_name}, {col}{t + off_label}, {col}{t + off_score}"}
                    if lab_raw is None and score is None:
                        entry.update(label=None, label_raw=None, score=None)   # Brahmasthan: no rating in the workbook
                    else:
                        key = re.sub(r"[^a-z]", "", str(lab_raw).lower())
                        if key not in LABEL_MAP:
                            sys.exit(f"Unknown label '{lab_raw}' at {ws.title}!{col}{t + off_label}")
                        r.used.add(f"{col}{t + off_label}")
                        entry.update(label=LABEL_MAP[key], label_raw=lab_raw, score=score)
                        if str(lab_raw).strip() != LABEL_MAP[key]:
                            out["label_variants_normalised"].setdefault(str(lab_raw).strip(), LABEL_MAP[key])
                    cells[code] = entry
            out["elements"].append({"slug": slug(name), "name": name, "sheet": ws.title, "title_cell": f"F{t}",
                                    "directions": cells})
        cover[ws.title] = r
    return out, cover


def main():
    num, ncover = import_numerology()
    vas, vcover = import_vastu()
    (ROOT / "data" / "numerology_workbook.json").write_text(json.dumps(num, indent=1, ensure_ascii=False), encoding="utf-8")
    (ROOT / "data" / "vastu_meter.json").write_text(json.dumps(vas, indent=1, ensure_ascii=False), encoding="utf-8")

    lines = ["# Data coverage (generated by tools/import_workbooks.py)", "",
             "Every non-empty cell of every sheet is either imported or listed under *Not imported*.", "",
             "| Workbook | Sheet | Non-empty cells | Imported | Not imported |", "|---|---|---|---|---|"]
    leftovers = []
    for wbname, cover in (("Numerology_Numbers_and_Formulas.xls", ncover), ("Vastu_Meter_ContentV1.xls", vcover)):
        for sheet, rd in cover.items():
            un = rd.unused()
            lines.append(f"| {wbname} | {sheet} | {rd.nonempty()} | {rd.nonempty() - len(un)} | {len(un)} |")
            leftovers += [(wbname, sheet, c, t) for c, t in un]
    lines += ["", f"Vastu elements imported: {len(vas['elements'])} (" + ", ".join(e['name'] for e in vas['elements']) + ")", ""]
    lines += ["## Not imported", ""] + ([f"- {w} / {s} / {c}: {t}" for w, s, c, t in leftovers] or ["- none"])
    lines += ["", "## Vastu label spellings normalised for display (original kept in data under `label_raw`)", ""]
    lines += [f"- `{k}` → {v}" for k, v in sorted(vas["label_variants_normalised"].items())]
    (ROOT / "docs" / "DATA_COVERAGE.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[:12])); print("leftovers:", len(leftovers)); print(leftovers[:10])


if __name__ == "__main__":
    main()
