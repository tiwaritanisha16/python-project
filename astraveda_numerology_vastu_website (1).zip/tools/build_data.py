"""
Builds data/numerology_data.json  (9 number profiles + 81 Moolank x Bhagyank combinations).

You do NOT need to run this to use the website - the finished JSON file is already included.
Run it only if you edit the content below and want to regenerate the JSON:

    py tools/build_data.py

Every one of the 81 combinations is composed from different ingredients of the two numbers
plus the traditional relationship between their ruling planets, so no two texts are identical.
"""
import json
from pathlib import Path

N = {
    1: dict(planet="Sun (Surya)", title="The Leader", adj="The Radiant", noun="Pioneer", color="Gold, Orange, Saffron", day="Sunday",
        theme="self-assertion and finding your own voice",
        personality="Born under the Sun, Moolank 1 carries natural authority, pride and a pioneering spirit. You prefer to lead rather than follow, and you carry a quiet dignity that others notice even when you say little.",
        core="a self-reliant, authoritative and proud nature",
        career=["leadership roles", "administration", "government service", "entrepreneurship", "management", "positions of authority"],
        love="loyal and generous in love, though you must guard against dominating your partner",
        marriage="you expect respect and devotion, and marriage grows steadier when you listen as much as you lead",
        finance="you earn well through initiative and status, and tend to spend generously on family and image",
        education="you do best when allowed to choose subjects independently; leadership, law and management suit you",
        strengths=["Courage", "Willpower", "Confidence", "Initiative"],
        challenges=["Ego", "Impatience", "Stubbornness", "Difficulty accepting advice"],
        remedies=["Offer water to the rising Sun each morning (Surya Arghya)", "Chant 'Om Suryaya Namah' on Sundays", "Use gold, orange or saffron tones in clothing", "Treat your father figures and elders with respect"]),
    2: dict(planet="Moon (Chandra)", title="The Nurturer", adj="The Intuitive", noun="Healer", color="White, Cream, Silver", day="Monday",
        theme="emotional learning and cooperation",
        personality="Ruled by the Moon, Moolank 2 is sensitive, imaginative and deeply intuitive. Your moods rise and fall like tides, and your greatest gift is the empathy with which you sense what others need.",
        core="a gentle, imaginative and emotionally perceptive nature",
        career=["counselling", "teaching", "the creative arts", "hospitality", "caregiving", "diplomacy", "social work"],
        love="tender and devoted, though prone to overthinking and emotional sensitivity",
        marriage="you value emotional security and a peaceful home, and mutual reassurance keeps the bond strong",
        finance="money flows in waves, so steady savings and trusted advisors bring stability",
        education="you learn best in calm, supportive settings; literature, psychology, design and the healing arts suit you",
        strengths=["Empathy", "Intuition", "Diplomacy", "Creativity"],
        challenges=["Mood swings", "Over-sensitivity", "Indecision", "Dependence on approval"],
        remedies=["Observe Monday fasting or offer milk to Lord Shiva", "Chant 'Om Chandraya Namah'", "Wear white or soft pearl-like tones", "Spend quiet time near water or in moonlight"]),
    3: dict(planet="Jupiter (Guru)", title="The Teacher", adj="The Wise", noun="Guide", color="Yellow, Saffron, Gold", day="Thursday",
        theme="learning, teaching and the growth of values",
        personality="Guided by Jupiter, Moolank 3 is optimistic, learned and morally inclined. You love knowledge, speak with warmth, and often become a guide or counsellor for the people around you.",
        core="an optimistic, wise and expressive nature",
        career=["teaching", "law", "advisory work", "finance", "writing", "spiritual guidance"],
        love="warm, principled and generous, and you seek a partner who shares your values and growth",
        marriage="you treat marriage as a sacred duty, and family blessings and shared ideals matter greatly",
        finance="you gain through knowledge and respected connections, but must avoid over-generosity and over-promising",
        education="you are naturally academic; philosophy, law, commerce, literature and teaching are favourable",
        strengths=["Wisdom", "Optimism", "Teaching ability", "Ethical outlook"],
        challenges=["Overconfidence", "A preaching tone", "Scattered energy", "Excess indulgence"],
        remedies=["Offer yellow flowers or chana dal on Thursdays", "Chant 'Om Gurave Namah'", "Respect your teachers and elders", "Wear yellow on Thursdays"]),
    4: dict(planet="Rahu", title="The Builder", adj="The Unconventional", noun="Innovator", color="Blue, Grey, Electric Blue", day="Saturday",
        theme="effort, structure and overcoming obstacles",
        personality="Linked with Rahu, Moolank 4 is practical, hardworking and often unconventional. You build through sustained effort, question inherited rules, and see angles that others miss.",
        core="an original, determined and unconventional nature",
        career=["engineering", "technology", "research", "real estate", "strategy", "unconventional ventures"],
        love="loyal but reserved, and you may find it hard to express feelings openly",
        marriage="you need honesty and mental freedom, and misunderstandings fade when you communicate plainly",
        finance="wealth grows slowly through disciplined effort, so avoid speculation and sudden risky schemes",
        education="you are strong in technical, analytical and research subjects, where persistence beats talent",
        strengths=["Persistence", "Practicality", "Organisation", "Originality"],
        challenges=["Rigidity", "Sudden obstacles", "Suspicion", "Restlessness"],
        remedies=["Light a lamp before Goddess Durga on Saturdays", "Chant 'Om Rahave Namah'", "Feed birds or care for street animals", "Keep your workspace tidy and your dealings honest"]),
    5: dict(planet="Mercury (Budh)", title="The Communicator", adj="The Agile", noun="Messenger", color="Green, Light Grey", day="Wednesday",
        theme="change, travel and quick opportunities",
        personality="Governed by Mercury, Moolank 5 is witty, versatile and quick to learn. Change and variety keep you alive, and you read situations faster than most people around you.",
        core="a quick, curious and adaptable nature",
        career=["trade", "media", "marketing", "accounting", "travel", "technology"],
        love="playful and communicative, though you may dread commitments that feel confining",
        marriage="you need mental companionship and variety, and open conversation protects the bond",
        finance="you have good commercial sense and often several income sources, but need discipline against impulsive spending",
        education="you are a fast learner; commerce, mathematics, languages, media and technology are favourable",
        strengths=["Adaptability", "Intelligence", "Humour", "Networking skill"],
        challenges=["Restlessness", "Nervous energy", "Inconsistency", "Impulsiveness"],
        remedies=["Offer green moong or feed a cow on Wednesdays", "Chant 'Om Budhaya Namah'", "Keep a journal to settle the mind", "Wear green on Wednesdays"]),
    6: dict(planet="Venus (Shukra)", title="The Artist", adj="The Graceful", noun="Harmoniser", color="White, Pink, Soft Pastels", day="Friday",
        theme="relationships, responsibility and creative expression",
        personality="Ruled by Venus, Moolank 6 is graceful, affectionate and drawn to beauty. You create harmony around you and place great value on family, refinement and comfort.",
        core="a charming, artistic and comfort-loving nature",
        career=["the arts", "fashion", "entertainment", "hospitality", "wellness", "luxury trades"],
        love="romantic and devoted, with high expectations of beauty and harmony",
        marriage="marriage is central to your happiness, and shared comforts and daily affection sustain it",
        finance="you attract comfort and resources, though luxury spending needs balance",
        education="you shine in arts, design, music, hospitality and communication",
        strengths=["Charm", "Creativity", "Loyalty", "Aesthetic sense"],
        challenges=["Indulgence", "Jealousy", "Vanity", "Avoiding hard conversations"],
        remedies=["Worship Goddess Lakshmi on Fridays", "Chant 'Om Shukraya Namah'", "Keep your home clean and fragrant", "Wear white or soft pastels on Fridays"]),
    7: dict(planet="Ketu", title="The Seeker", adj="The Contemplative", noun="Seeker", color="Sea Green, Pale Grey, Smoky Tones", day="Tuesday",
        theme="inner search and specialised knowledge",
        personality="Linked with Ketu, Moolank 7 is introspective, analytical and drawn to deeper truths. You need solitude to recharge and often feel a quiet pull toward the mystical and the unexplained.",
        core="a reflective, spiritual and analytical nature",
        career=["research", "spiritual teaching", "philosophy", "writing", "science", "healing", "analysis"],
        love="deep but private; you are slow to trust, yet profoundly sincere once you do",
        marriage="you need space and a partner who respects silence, and emotional distance is the main risk",
        finance="the flow may be modest and unpredictable early on, improving as you build specialised knowledge",
        education="you suit research, philosophy, science, occult studies and writing",
        strengths=["Insight", "Depth of thought", "Detachment", "Spiritual inclination"],
        challenges=["Isolation", "Moodiness", "Over-analysis", "Secretiveness"],
        remedies=["Offer food to dogs or cows", "Chant 'Om Ketave Namah'", "Practise daily meditation or silent time", "Visit a Ganesha temple on Tuesdays"]),
    8: dict(planet="Saturn (Shani)", title="The Disciplined One", adj="The Steadfast", noun="Builder", color="Dark Blue, Black, Charcoal", day="Saturday",
        theme="discipline, patience and hard-won stability",
        personality="Ruled by Saturn, Moolank 8 matures through hard work and perseverance. Life often tests you early, but patience and fairness reward you late and lastingly.",
        core="a disciplined, serious and enduring nature",
        career=["administration", "law", "industry", "construction", "social service", "institutional careers"],
        love="serious and loyal, expressing affection through responsibility more than words",
        marriage="commitment may come with delay or maturity, and it grows stronger with time",
        finance="accumulation is slow, steady and lasting, and fortune often improves after the early thirties",
        education="you are a persistent student; law, engineering, management and social science suit you",
        strengths=["Patience", "Discipline", "Fairness", "Endurance"],
        challenges=["Delays", "Pessimism", "Loneliness", "Rigidity"],
        remedies=["Light a sesame-oil lamp under a Peepal tree on Saturdays", "Chant 'Om Shanaishcharaya Namah'", "Serve the elderly, workers and the needy", "Wear dark blue on Saturdays"]),
    9: dict(planet="Mars (Mangal)", title="The Warrior", adj="The Fearless", noun="Champion", color="Red, Crimson, Coral", day="Tuesday",
        theme="action, courage and protecting others",
        personality="Ruled by Mars, Moolank 9 is bold, energetic and protective. You act with courage and speak plainly, and your energy turns into success when it is given a clear direction.",
        core="a courageous, energetic and passionate nature",
        career=["defence", "sports", "surgery", "engineering", "law enforcement", "real estate"],
        love="passionate and protective, though impatience can cause quick quarrels",
        marriage="you need a partner who can match your energy, and patience in speech keeps harmony",
        finance="you earn through effort and courage, but should avoid impulsive investments and money conflicts",
        education="you do well in action-oriented subjects such as sports science, engineering, medicine and defence studies",
        strengths=["Courage", "Stamina", "Honesty", "A protective spirit"],
        challenges=["Anger", "Impatience", "Recklessness", "Argumentativeness"],
        remedies=["Offer red flowers to Lord Hanuman on Tuesdays", "Chant 'Om Mangalaya Namah'", "Exercise regularly to channel your energy", "Practise pausing before speaking in anger"]),
}

FRIENDS = {1: [2, 3, 5, 9], 2: [1, 3, 5], 3: [1, 2, 5, 9], 4: [5, 6, 7, 8], 5: [1, 2, 3, 4, 6],
           6: [4, 5, 8], 7: [4, 5, 6], 8: [4, 5, 6], 9: [1, 3, 5]}
ENEMIES = {1: [8], 2: [4, 8], 3: [6], 4: [2], 5: [], 6: [1, 3], 7: [], 8: [1, 2], 9: [8]}


def relation(m, b):
    if m == b:
        return "double"
    if b in ENEMIES[m] or m in ENEMIES[b]:
        return "challenging"
    if b in FRIENDS[m] and m in FRIENDS[b]:
        return "harmonious"
    if b in FRIENDS[m] or m in FRIENDS[b]:
        return "supportive"
    return "neutral"


def rot(items, k, n):
    k = k % len(items)
    r = items[k:] + items[:k]
    return r[:n]


def join(items):
    items = list(items)
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " and " + items[-1]


def nums(l):
    return ("number " if len(l) == 1 else "numbers ") + join(map(str, l))


def cap(s):
    return s[0].upper() + s[1:]


def number_details():
    out = []
    for n, d in N.items():
        out.append(dict(
            number=n, planet=d["planet"], title=d["title"], lucky_color=d["color"], lucky_day=d["day"],
            personality=d["personality"],
            career=f"Traditionally favourable fields include {join(d['career'])}. Choose work that gives your {d['strengths'][0].lower()} room to show.",
            love=f"In love you are {d['love']}. For marriage, {d['marriage']}.",
            finance=cap(d["finance"]) + ".",
            education=cap(d["education"]) + ".",
            strengths="\n".join(d["strengths"]),
            challenges="\n".join(d["challenges"]),
            remedies="\n".join(d["remedies"]),
        ))
    return out


def combos():
    out = []
    for m in range(1, 10):
        for b in range(1, 10):
            M, B = N[m], N[b]
            rel = relation(m, b)
            v = (m * 2 + b) % 3
            mp, bp = M["planet"].split(" (")[0], B["planet"].split(" (")[0]
            title = f"{M['adj']} {B['noun']}"

            rel_line = {
                "double": f"Because {mp} rules both your birth number and your destiny number, its qualities are amplified - gifts and lessons alike arrive in double measure.",
                "harmonious": f"{mp} and {bp} are traditionally friendly, so your inner temperament and your life path tend to support one another.",
                "supportive": f"{mp} and {bp} share a workable understanding, so progress comes smoothly when you consciously balance the two sides of yourself.",
                "neutral": f"{mp} and {bp} neither clash nor strongly assist each other, so results depend largely on your own effort and choices.",
                "challenging": f"{mp} and {bp} are traditionally uneasy companions, so you may feel a tug between who you are and what life asks of you - awareness turns that friction into strength.",
            }[rel]

            if m == b:
                personality = [
                    f"Both your Moolank and Bhagyank are {m}, ruled by {M['planet']}. This gives you {M['core']} that shows up consistently in who you are and where life leads you. {rel_line}",
                    f"With {m} as both birth number and destiny number, you are a concentrated expression of {mp}. Expect {M['core']} to define your character, and expect life to keep returning to the theme of {M['theme']}. {rel_line}",
                    f"A double {m} is a strong signature in traditional numerology. The influence of {M['planet']} gives you {M['core']}, and your path repeatedly asks you to master {M['theme']}. {rel_line}",
                ][v]
            else:
                personality = [
                    f"Your outer nature, shaped by {M['planet']}, is {M['core']}. Your destiny number {b} adds the colour of {B['planet']}: {B['core']}. {rel_line}",
                    f"As Moolank {m} you lean toward {M['core']}, yet Bhagyank {b} steers your life through {B['theme']}. {rel_line}",
                    f"You were born with {M['core']} ({mp}), and life gradually draws out {B['core']} ({bp}). {rel_line}",
                ][v]

            mc, bc = rot(M["career"], b, 3), rot(B["career"], m + (2 if m == b else 0), 3)
            career = [
                f"Your natural inclinations point toward {join(mc)}. Your destiny number adds an attraction to {join(bc)}. The most satisfying path usually blends both, for example a role that combines {mc[0]} with {bc[0]}.",
                f"Traditionally, Moolank {m} succeeds in {join(mc)}, while Bhagyank {b} opens doors in {join(bc)}. Early career tends to be shaped by {M['theme']}, and later growth by {B['theme']}.",
                f"Look first at {join(mc)}; your temperament fits them. As your destiny unfolds, {join(bc)} may become important. Success is strongest where {mc[1]} and {bc[1]} can meet.",
            ][v]
            if rel == "challenging":
                career += " Expect a few career changes before the two sides settle into a clear direction."
            elif rel in ("harmonious", "double"):
                career += " Your temperament and destiny pull the same way, so focus and consistency bring steady rewards."

            love = [
                f"In love you are {M['love']}. With Bhagyank {b}, you are also {B['love']}.",
                f"Your heart, shaped by {mp}, is {M['love']}. Over time, the influence of {bp} makes you {B['love']}.",
                f"Relationships bring out two sides of you: {M['love']}, and also {B['love']}.",
            ][v]
            love += {
                "double": " The same energy in heart and destiny makes your style of loving very consistent; you need a partner who can handle its intensity.",
                "harmonious": " Heart and destiny agree, so relationships tend to feel natural once trust is built.",
                "supportive": " Your emotional style and life path cooperate well, especially when you communicate openly.",
                "neutral": " Your relationship style is shaped more by experience than by any single planetary push, so each bond teaches you something different.",
                "challenging": " Your emotions and life direction may pull apart at times, so honest self-reflection matters before big relationship decisions.",
            }[rel]

            marriage = [
                f"For marriage, {M['marriage']}. Your destiny number suggests that {B['marriage']}.",
                f"Traditionally, {M['marriage']}, while Bhagyank {b} adds that {B['marriage']}.",
                f"In married life, {M['marriage']}; further, {B['marriage']}.",
            ][v]
            marriage += {
                "double": " Marriage tends to follow the pattern of your number strongly, so choose a partner who respects it.",
                "harmonious": " Marital harmony is generally favoured when you stay patient and share responsibilities.",
                "supportive": " A supportive partner who values your growth helps both numbers work in your favour.",
                "neutral": " Timing of marriage is flexible, and compatibility of values counts more than any single number.",
                "challenging": " Give extra weight to understanding and compromise; a calm, patient partner helps balance the tension between your two numbers.",
            }[rel]

            education = [
                f"Educationally, {M['education']}. Bhagyank {b} adds that {B['education']}.",
                f"Moolank {m} suggests that {M['education']}, and Bhagyank {b} adds that {B['education']}.",
                f"Study works best when it matches your nature: {M['education']}. Later in life, {B['education']}.",
            ][v]

            finance = [
                f"Financially, {M['finance']}. With destiny number {b}, {B['finance']}.",
                f"On money matters, {M['finance']}, while Bhagyank {b} shows that {B['finance']}.",
                f"Your relationship with money has two layers: {M['finance']}; and over the years, {B['finance']}.",
            ][v]
            finance += {
                "double": " Because the same planet governs both numbers, both your gains and your habits repeat strongly - build discipline around them.",
                "harmonious": " Income and opportunity tend to move together, which helps long-term savings.",
                "supportive": " Gains are steady when you keep spending and saving in balance.",
                "neutral": " Money comes mostly through personal effort, so planning matters more than luck.",
                "challenging": " Income may swing before it settles, so keep an emergency reserve and avoid impulsive financial decisions.",
            }[rel]

            strengths = rot(M["strengths"], b, 2) + rot(B["strengths"], m, 2)
            strengths = list(dict.fromkeys(s.lower() for s in strengths))
            strengths_txt = "\n".join(cap(s) for s in strengths)

            challenges = rot(M["challenges"], b + 1, 2) + rot(B["challenges"], m + 1, 2)
            challenges = list(dict.fromkeys(c.lower() for c in challenges))
            challenges_txt = "\n".join(cap(c) for c in challenges)
            if rel == "challenging":
                challenges_txt += f"\nInner tug between {mp} and {bp} energies"
            elif rel == "double":
                challenges_txt += f"\nExtremes of {mp} energy when unbalanced"

            fm = [x for x in FRIENDS[m]]
            fb = [x for x in FRIENDS[b]]
            both = sorted(set(fm) & set(fb))
            best = both if both else sorted(set(fm + fb))
            avoid = sorted(set(ENEMIES[m] + ENEMIES[b]) - {m, b})
            compat = f"Moolank {m} traditionally gets along best with {nums(fm)}, and Bhagyank {b} with {nums(fb)}. "
            compat += f"For friendship, business and marriage, {nums(best)} {'is' if len(best)==1 else 'are'} especially supportive for you. "
            compat += (f"Take extra care in close partnerships with {nums(avoid)}, where temperaments may clash." if avoid
                       else "No number is strongly opposed to your combination, so compatibility depends mostly on character and values.")

            remedies = [rot(M["remedies"], b, 2)[0], rot(M["remedies"], b, 2)[1], rot(B["remedies"], m, 2)[0],
                        (f"Keep {M['day']} (ruled by both your numbers) as your day of reflection, and favour {M['color'].split(',')[0]} tones" if M['day'] == B['day'] else f"Keep {M['day']} (for Moolank {m}) and {B['day']} (for Bhagyank {b}) as your reflective days, and favour {M['color'].split(',')[0]} and {B['color'].split(',')[0]} tones")]
            remedies = list(dict.fromkeys(remedies))

            first = {
                "double": f"A double {m} makes you a pure, concentrated expression of {mp}.",
                "harmonious": f"Your birth number and destiny number work as friends, pointing in a similar direction.",
                "supportive": f"Your two numbers cooperate, giving you room to grow if you stay balanced.",
                "neutral": f"Your two numbers stand side by side without strong interference, leaving your choices to shape the outcome.",
                "challenging": f"Your two numbers create a lively inner tension that, once understood, becomes a source of depth.",
            }[rel]
            summary = (f"Moolank {m} with Bhagyank {b} - {title}. {first} "
                       f"Early life tends to revolve around {M['theme']}, while the later path moves toward {B['theme']}. "
                       f"The greatest strength of this combination is {strengths[0]} joined with {strengths[-1]}, and the main lesson is to watch {challenges[0]} and {challenges[-1]}. "
                       f"Traditionally, steady practice of your remedies and respect for your ruling days is believed to support harmony.")

            out.append(dict(moolank=m, bhagyank=b, personality=personality, career=career, love=love, marriage=marriage,
                            education=education, finance=finance, strengths=strengths_txt, challenges=challenges_txt,
                            compatibility=compat, remedies="\n".join(remedies), overall_summary=summary))
    return out


if __name__ == "__main__":
    data = {"numbers": number_details(), "combinations": combos()}
    path = Path(__file__).resolve().parent.parent / "data" / "numerology_data.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    uniq = len({c["overall_summary"] for c in data["combinations"]})
    print(f"Wrote {path}  ({len(data['numbers'])} numbers, {len(data['combinations'])} combinations, {uniq} unique summaries)")
