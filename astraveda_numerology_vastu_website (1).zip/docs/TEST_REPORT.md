# Test report

## Run automatically (`py -m unittest discover -s tests`): 62 tests, all passed
* **Website and existing features** (27 tests): home and all page routes (including the new Numerology and Vastu pages) open; header has one button and the home page has the two hero buttons; every link on the home page resolves; 404 page; consent box and photo rules
  (no photo / face only / palm only / both; photos never required; consent only when a photo is uploaded); invalid uploads; CSRF;
  full flow preview → demo payment → report with only the chosen categories; deletion of photos and readings; photo retention clean-up;
  Gemini missing key / error / success paths (fake module, no real call); migration of an old database with its records kept; Astro Buddy/Instagram/phone configuration; URL safety.
* **Numerology workbook** (16 tests): reduction and master numbers; Life Path, Birthday, Attitude, Karmic against the workbook examples; name numbers for “VIDYA SINGH”;
  Y/W vowel rule; intensified/absent numbers; maturity; pinnacles and challenges (ages from the workbook table); personal cycles (Sheet2 examples);
  **essence number reproduces all 74 rows** of the workbook's worked table; transit letters (26 letters); both letter tables complete; edge inputs (1900, leap day, master-number years, single/hyphenated names).
* **Vastu workbook, Vastu pages and calculator page** (19 tests): 33 rooms from 3 sheets; **every one of the 297 direction cells re-read from the original workbook and compared**; Brahmasthan unrated everywhere;
  label normalisation; known values; grouping covers every room once; meter average, rounding, boundaries, invalid and unrated input; every room page opens; meter page results and error handling; calculator page validation, CSRF and “nothing is stored”.

## Landing page change (latest)
Only `templates/index.html`, the `index()` route in `app.py`, `static/style.css` and `tests/test_site.py` changed; every other file is byte-identical to the previous build (checked with a directory diff).
Tested: the landing page has exactly two buttons, to `/numerology` and `/vastu`; both open (also in a browser at 1366 px and 390 px, no overflow, no console errors); the existing preview → locked report → demo payment → report flow and the Vastu pages still pass their tests.

## Checked in a real browser (headless Chromium, by script)
Home, Numerology, Vastu Meter result, room page, calculator result, Personal Reading form → preview → demo payment → report at 1366 px and 390 px wide:
no horizontal scrolling, no JavaScript errors, mobile menu opens, header dropdown shows on hover, consent error appears when a photo is chosen without the box ticked.

## Not tested (please check yourself)
* A real Gemini call (needs your API key) and whether the model name in `.env` is still offered by Google.
* Real Razorpay payments (the demo payment was tested).
* Real phones and other browsers (Safari, Firefox); only Chromium emulation was used.
* The final ZIP running on your Windows PC from a fresh folder (the same install steps were run by you earlier; the tests were run here on Linux).
* Print / Save as PDF output on your printer.
* Whether your four photos may be used commercially (their source and licence are not known to me).
* Trademark or domain availability of “Astro Buddy”.
