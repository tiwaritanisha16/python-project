# Change summary

**Brand and design** — new name Astro Buddy (working name), new logo, favicon and wordmark; midnight-navy hero with a fading starfield, soft glows,
an arched photo frame and a typed hero heading; ivory/white content pages; gold accents; header with logo left, centred menu with
Numerology and Vastu dropdowns and one Contact button on the right; footer with both services; your four photos used on Home, Numerology, Vastu and About.

**Numerology** — Core Numbers Calculator (Life Path with master numbers, Destiny, Soul Urge, Personality, Birthday, Attitude, Karmic, Growth,
Habit Challenge, Maturity, intensified/absent numbers, personal and universal cycles, four pinnacles and challenges with ages, life-path periods,
essence number, transit letters; Pythagorean or Chaldean letters; every step shown; nothing stored); Number Guide with every workbook table;
core numbers added to the complete Personal Reading. Existing Moolank/Bhagyank rules are unchanged.

**Vastu** — Vastu landing page, Room-by-Room Guide (33 rooms, colour-coded compass + table), Vastu Meter (direction per room, ratings, average, best directions).

**Data** — both workbooks imported into JSON by `tools/import_workbooks.py`, with a coverage report; originals kept in `docs/source_data/`.

**Kept from the previous version** — optional face/palm photos with consent, Gemini integration (server side, safe fallbacks), preview + complete report,
demo/real payment, privacy and terms pages, photo retention and deletion, database migration, CSRF protection.

**Content** — less “AI” wording (Gemini is mentioned only where photos are processed); honest “Why choose us”; no invented experience, testimonials or statistics.

**Latest change — simple landing page.** The home page is now only a landing page with two entrances (Numerology → `/numerology`, Vastu Shastra → `/vastu`). The long homepage sections were removed from the home page only; all other pages, routes, data, calculations, reports and the payment flow are unchanged.

**Landing page redesign.** Brand name is now Astro Buddy (set by `SITE_NAME` in `.env`; the wordmark uses the Cinzel font with a Georgia fallback). The landing page has no menu and no footer links, only the brand, one line of introduction and two equal service cards (Numerology, Vastu Shastra). Both images are 16:9 crops (`static/img/landing-numerology.jpg`, `landing-vastu.jpg`, cut from your photos with the subject centred), shown with `object-fit: cover` so they are never stretched. Cards have identical size and aligned buttons; on phones they stack. The landing styles use their own class names (`.landing`, `.svc`), so the Numerology and Vastu pages are unaffected; those pages keep the normal header and footer.

**Header photos fixed.** The Numerology, Vastu and About page photos were rendered very tall because the image's HTML height attribute overrode its aspect ratio. They now sit in a `.ph-frame` (fixed 3:2 / 4:3 ratio, `object-fit: cover`), using the same crops as the landing page, so they are never taller than the text beside them.

**Alignment polish.** Header logo/menu container now has the same width as page content, so the logo lines up with the text and the Contact button with the photo's right edge. Header photos are 480 px wide frames vertically centred beside the text. The tool cards on the Numerology and Vastu pages have equal heights with their links on one line.
