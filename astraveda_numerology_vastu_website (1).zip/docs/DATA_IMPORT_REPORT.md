# Data import report

Source files (originals kept in `docs/source_data/`, with plain `.xlsx` conversions used by the importer):

* `Numerology_Numbers_and_Formulas.xls` — 3 sheets
* `Vastu_Meter_ContentV1.xls` — 3 sheets

`tools/import_workbooks.py` reads every cell. The generated `docs/DATA_COVERAGE.md` shows, per sheet, how many non-empty cells exist and
how many were imported: **all 1,235 numerology cells and all 858 Vastu cells are imported; 0 are left out.**

## 1. Numerology_Numbers_and_Formulas.xls

| Sheet | Purpose | Cells | Where it is used |
|---|---|---|---|
| **Numerology Table** | 24 numerology numbers with “also called” and the formula in words | 97 | Number Guide → “The 24 numerology numbers”; drives which numbers the calculator offers |
| **Sheet2** | 19 “core numbers” (Life Path, Destiny, Soul Urge, Personality, Birthday, Intensified, Absent, Growth, Habit Challenge, Maturity, Karmic, Personal Year/Month/Day, Life Path Period, Pinnacle, Challenge, Essence, Transit): what each is based on, what it describes, a worked example, notes | 105 | Number Guide (shown exactly as written); the “what it describes” text appears on calculator cards; rules implemented in `numerology_core.py` |
| **Sheet1** | Reference tables: Chaldean and Pythagorean letter values, vowel values, intensified/absence table, combination matrix, life-period table, pinnacle table, challenge themes, a 74-row essence-number worked table, transit letters | 1,033 (292 formulas) | Calculator (letter values, pinnacle ages, challenge themes, transit letters, essence); Number Guide (all tables) |

### Numbers from the “Numerology Table” and their status
Implemented in the calculator: Mulank, Bhagyank/Life Path, Birth Day, Compound, Name/Destiny/Expression, Soul Urge, Personality,
Maturity, Attitude, Personal Year/Month/Day, Universal Year/Month/Day, Karmic (day + month rule), Master numbers (11/22/33 kept),
Life Lesson (absent numbers), Hidden Passion (intensified), Challenge, Pinnacle.
**Not implemented:** *Balance Number* (“based on initial letters of the name”, no rule given) and *Lucky Number* (“usually derived from …”, no rule given).
The 1–9 lucky colours/days from the original project database are still shown in the Personal Reading.

### Ambiguities and how they were handled
1. **Worked-example slips (Sheet2).** In “VIDYA SINGH”, Destiny uses H = 9 once (H = 8 elsewhere) and Personality counts the vowel A among consonants. Printed answers: Destiny 11, Personality 3. Rules applied correctly: Destiny 1, Personality 11. The rules are implemented; the examples are shown as written.
2. **4th pinnacle example.** 3 + 1982 → printed 4; rule gives 5.
3. **Pinnacle ages.** Example text “35 to 43”, table “36–44”. The table is used. Challenge ages use the same table (Sheet2 says they follow the pinnacle ages).
4. **Intensified numbers.** Cell I30 says take all tied numbers; cell I33 says take only two. All tied numbers are shown.
5. **Y and W as vowels.** Note says “if the preceding letter is a vowel”; the VIDYA example treats Y as a vowel because A follows. A vowel on either side is used.
6. **Chaldean table.** Written S = 5 and X = 3 (many published tables differ). Used as written; edit `data` via the importer if wrong.
7. **Combination matrix.** `+`, `-`, `0` are not explained and 6&9 / 2&3 conflict with the named lists in Sheet2 I27. Both are displayed, neither is interpreted.
8. **Life-period table.** Some rows overlap (e.g. 2nd period ends 54, 3rd starts 53) and one cell reads “51`”. Shown as printed; the calculator shows the printed ages.
9. **Row 36 of the intensified table** (“3 to 4”, 1, 0, “0 to 1” …) has no explanation. Shown, not used.
10. **Row 38 “Essence Number Year”** contains only the headers 1–9, with no data below it. Nothing to import.
11. **Essence rule.** Not stated in words. It was inferred from the 74-row worked table (each letter active for as many years as its value; first-name letter value + last-name letter value, reduced, 11/22/33 kept) and **verified against all 74 rows** in the tests. The middle-name column is empty in the source, so only first and last names are used.
12. **Transit table typo.** Number 2 lists “k” in lowercase; treated as K.
13. **Numbering.** Sheet2 numbers two items “16” and has no “17”.
14. **Name number reduction.** Each word is reduced (master numbers kept), the word totals are added and reduced again (11/22/33 kept). The workbook examples reduce parts the same way.

## 2. Vastu_Meter_ContentV1.xls

| Sheet | Rooms / elements | Cells |
|---|---|---|
| **vastucheck** | Main Door, Kitchen, Master Bedroom, Children's Bedroom, Guest Room, Dining Room, Well or Underground Tank, Toilet or Bathroom, Garage, House in Plot (10) | 260 |
| **utecbyultratech** | Balcony, Parking, Pooja Room, Porch, Staircase, Store Room, Utility Room, Verandah, Open Space, Living Room, Drawing Room (11) | 286 |
| **Additional** | Study Room, Home Office, Overhead Water Tank, Septic Tank, Borewell / Water Source, Garden / Lawn, Swimming Pool, Meditation Area, Gym / Workout Area, Lift / Elevator, Basement, Servant Room (12) | 312 |

Each element has a block of 9 positions (NE, East, SE, North, Brahmasthan, South, NW, West, SW). For eight of them the workbook gives a rating label and a score (1–10). **The workbook contains no formulas**, no units, and no explanatory text.

Used in: Room-by-Room Guide (all 33 rooms, compass + table), Vastu Meter (lookup of the chosen direction), Vastu landing page.

### Ambiguities and how they were handled
1. **Brahmasthan** (centre) has a name but **no label and no score** in any block. Shown as “not rated in the source” and left out of the meter.
2. **No overall-meter formula.** The workbook gives per-direction scores only. The meter shows the **average of the scores chosen**, clearly labelled on the page as a summary added by the website.
3. **Label spellings.** Typos such as “Highly Inasupicious”, “InAupicious”, “Higly Inauspicious”, “CanBe Better” were normalised for display to six labels (Very Auspicious, Highly Auspicious, Auspicious, Can Be Better, Inauspicious, Highly Inauspicious). The original text is kept in `data/vastu_meter.json` as `label_raw`; the list is in `docs/DATA_COVERAGE.md`.
4. **“Very Auspicious” vs “Highly Auspicious”** appear as separate labels in the source (Main Door uses “Very”). Both are kept.
5. Label and score are not always consistent between rooms (e.g. a 9 can be “Highly Auspicious” in one room and “Auspicious” in another). Each cell is shown as written.
6. **Sheet names** (“utecbyultratech”, “Additional”) do not describe their content. The website groups rooms by function for browsing; that grouping is the website's, not the workbook's.
7. Vastu introduction text on the website is general and written for the site; it does not claim rules the workbook does not contain.
