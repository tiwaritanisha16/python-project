# Editing guide

## Update numerology or Vastu content from Excel
1. Edit the workbook in Excel. Keep the same layout (each Vastu room is a 26-cell block; see the existing sheets).
2. Save a copy as `.xlsx` into `docs/source_data/` with the same file name (`Numerology_Numbers_and_Formulas.xlsx` or `Vastu_Meter_ContentV1.xlsx`). Keep the `.xls` there too if you want the original.
3. Run `py tools/import_workbooks.py`. It rewrites `data/numerology_workbook.json`, `data/vastu_meter.json` and `docs/DATA_COVERAGE.md`.
   If a Vastu label it does not know appears, it stops and tells you which cell; add the spelling to `LABEL_MAP` in the script.
4. Run the tests: `py -m unittest discover -s tests`. Restart the site.

## Add another Vastu room
Add a new 26-cell block to any Vastu sheet in the same layout, re-run the importer. It appears in the guide and the meter automatically
(rooms not listed in `GROUPS` in `vastu.py` show under “Other”; add its slug to a group to place it).

## Add another Vastu tool
Put logic in `vastu.py` (keep it free of HTML), add a route in `app.py` (copy `vastu_meter`), a template in `templates/`, a menu entry in `NAV` in `app.py`, and tests in `tests/test_workbook_vastu.py`.

## Change contact details
Edit `.env`: `ASTROLOGER_NAME`, `ASTROLOGER_PHONE`, `ASTROBUDDY_URL`, `ASTROLOGER_INSTAGRAM_URL` (URLs must start with `https://`). Restart the site.

## Change the name, logo or colours
* Name: `SITE_NAME` in `.env`.
* Logo: `static/img/logo.svg` (header and footer), `static/img/logo-mark.svg` and `static/img/favicon.svg`. Keep the same file names.
* Colours: the `:root { ... }` block at the top of `static/style.css` (`--navy`, `--blue`, `--gold`, `--ivory` ...).
* Photos: `static/img/photos/` (`planets-portrait.jpg` hero, `zodiac-desk.jpg` Numerology, `ritual-chart.jpg` Vastu, `hand-chart-night.jpg` About). Replace the files, keep the names.

## Change page text
Pages are in `templates/`. FAQ text is in `site_content.py`. Number 1–9 reflection text is in `content_extra.py`.
Make sure you only publish photos and text you have the right to use.
