"""Run with:  py -m unittest discover -s tests -v     (from the project folder)"""
import io
import os
import re
import sqlite3
import sys
import tempfile
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = Path(tempfile.mkdtemp())
os.environ.pop("GEMINI_API_KEY", None)

import database  # noqa: E402
database.DB_PATH = TMP / "test.db"
import app as appmod  # noqa: E402
import gemini_ai  # noqa: E402
import numerology  # noqa: E402
from PIL import Image  # noqa: E402

appmod.UPLOAD_DIR = TMP / "uploads"
appmod.UPLOAD_DIR.mkdir(exist_ok=True)
appmod.app.config["TESTING"] = True
database.init_db()


def png(color=(200, 150, 100)):
    buf = io.BytesIO()
    Image.new("RGB", (60, 60), color).save(buf, "PNG")
    buf.seek(0)
    return buf


class Base(unittest.TestCase):
    def setUp(self):
        self.c = appmod.app.test_client()

    def token(self, path="/reading"):
        html = self.c.get(path).get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)

    def submit(self, face=False, palm=False, consent=False, **over):
        data = {"csrf_token": self.token(), "name": "Test User", "gender": "Male", "dob": "2002-07-16",
                "categories": ["love", "career"]}
        data.update(over)
        if face:
            data["face_image"] = (png(), "face.png")
        if palm:
            data["palm_image"] = (png((10, 90, 200)), "palm.png")
        if consent:
            data["photo_consent"] = "on"
        return self.c.post("/reading", data=data, content_type="multipart/form-data")

    def reading_id(self, resp):
        self.assertEqual(resp.status_code, 302, resp.get_data(as_text=True)[:400])
        return resp.headers["Location"].rsplit("/", 1)[1]


class TestNumerology(unittest.TestCase):
    def test_known_dates(self):
        cases = {"2002-07-16": (7, 9), "1999-12-29": (2, 6), "1990-01-01": (1, 3), "1985-11-10": (1, 8),
                 "2000-02-09": (9, 4), "1975-09-18": (9, 4), "1988-08-08": (8, 6), "1950-10-20": (2, 9)}
        for dob, (m, b) in cases.items():
            self.assertEqual(numerology.calculate_numbers(dob), {"moolank": m, "bhagyank": b}, dob)

    def test_explanations(self):
        self.assertIn("Moolank = 7", numerology.explain_moolank("2002-07-16"))
        self.assertIn("18 → 1+8 = 9", numerology.explain_bhagyank("2002-07-16"))
        self.assertIn("already a single digit", numerology.explain_moolank("2002-07-05"))

    def test_invalid_dates(self):
        for bad in ("", "1800-01-01", "2999-01-01", "abc"):
            with self.assertRaises(ValueError):
                numerology.parse_dob(bad)


class TestPages(Base):
    PAGES = ["/", "/about", "/how-it-works", "/reading", "/categories", "/faq", "/contact", "/privacy", "/terms",
             "/numerology", "/numerology/calculator", "/numerology/guide", "/vastu", "/vastu/guide", "/vastu/guide/main-door", "/vastu/meter"]

    def test_pages_open(self):
        for p in self.PAGES:
            self.assertEqual(self.c.get(p).status_code, 200, p)

    def test_navigation_links_resolve(self):
        html = self.c.get("/").get_data(as_text=True)
        hrefs = set(re.findall(r'href="(/[^"#]*)', html))
        self.assertTrue(hrefs)
        for h in hrefs:
            if h.startswith("/static"):
                continue
            self.assertEqual(self.c.get(h).status_code, 200, h)
        
    def test_landing_page_has_two_entrances(self):
        html = self.c.get("/").get_data(as_text=True)
        self.assertIn("Astro Buddy", html)
        self.assertNotIn("AstraVeda", html)
        self.assertNotIn("AstroVedi", html)
        self.assertNotIn('<header class="nav">', html)              # no site navigation bar on the landing page
        self.assertNotIn('<footer class="footer">', html)           # no footer navigation
        main = html.split("<main")[1].split("</main>")[0]
        self.assertIn("Numerology", main)
        self.assertIn("Vastu Shastra", main)
        self.assertEqual(re.findall(r'<a [^>]*href="([^"]+)"', main), ["/numerology", "/vastu"])   # only the two service links
        self.assertEqual(main.count('class="svc-img"'), 2)          # two equal image frames
        for word in ("Contact Us", "About Us", "How It Works", "FAQ", "Why choose us"):
            self.assertNotIn(word, html)
        for target in ("/numerology", "/vastu"):
            self.assertEqual(self.c.get(target).status_code, 200)

    def test_header_photos_use_fixed_ratio_frames(self):
        for path in ("/numerology", "/vastu", "/about"):
            html = self.c.get(path).get_data(as_text=True)
            self.assertIn('class="ph-frame', html, path)
            self.assertNotIn('class="arch"', html.split("<main")[1], path)   # old tall bare-image markup is gone

    def test_landing_targets_are_the_existing_sections(self):
        n = self.c.get("/numerology").get_data(as_text=True)
        self.assertIn("/reading", n)                                  # existing Personal Reading
        self.assertIn("/numerology/calculator", n)
        v = self.c.get("/vastu").get_data(as_text=True)
        self.assertIn("/vastu/meter", v)
        self.assertIn("/vastu/guide", v)

    def test_header_has_one_cta_and_centred_menu(self):
        html = self.c.get("/numerology").get_data(as_text=True)
        header = html.split("</header>")[0]
        self.assertEqual(header.count('class="btn btn-gold btn-sm nav-cta"'), 1)
        self.assertIn("Numerology", header)
        self.assertIn("Vastu", header)

    def test_404_page(self):
        r = self.c.get("/nope")
        self.assertEqual(r.status_code, 404)
        self.assertIn("Page not found", r.get_data(as_text=True))

    def test_hand_guidance_and_optional_text(self):
        html = self.c.get("/reading").get_data(as_text=True)
        self.assertIn("Male users should upload their right-hand photo.", html)
        self.assertIn("Female users should upload their left-hand photo.", html)
        self.assertIn("I understand that any photo I choose to upload may be processed by Google Gemini AI to generate my reading.", html)
        self.assertNotIn("required", re.search(r'<input type="file" id="face_image"[^>]*>', html).group(0))
        self.assertNotIn("required", re.search(r'<input type="file" id="palm_image"[^>]*>', html).group(0))


class TestAstroConfig(Base):
    def test_placeholders_then_configured(self):
        for k in ("ASTROBUDDY_URL", "ASTROLOGER_INSTAGRAM_URL", "ASTROLOGER_PHONE"):
            os.environ.pop(k, None)
        html = self.c.get("/contact").get_data(as_text=True)
        self.assertIn("not set yet", html)
        self.assertIn("0001 (placeholder number)", html)
        os.environ.update(ASTROBUDDY_URL="https://example.test/ab", ASTROLOGER_INSTAGRAM_URL="https://example.test/ig", ASTROLOGER_PHONE="+91 98765 43210")
        try:
            html = self.c.get("/contact").get_data(as_text=True)
            self.assertIn('href="https://example.test/ab"', html)
            self.assertIn('href="https://example.test/ig"', html)
            self.assertIn('href="tel:+919876543210"', html)
            self.assertNotIn("(placeholder number)", html)
        finally:
            for k in ("ASTROBUDDY_URL", "ASTROLOGER_INSTAGRAM_URL", "ASTROLOGER_PHONE"):
                os.environ.pop(k, None)


class TestForm(Base):
    def test_validation_messages(self):
        r = self.submit(name="", gender="", dob="", categories=[])
        self.assertEqual(r.status_code, 400)
        html = r.get_data(as_text=True)
        for msg in ("enter your full name", "select your gender", "date of birth", "at least one reading category"):
            self.assertIn(msg, html)

    def test_csrf_required(self):
        r = self.c.post("/reading", data={"name": "x"})
        self.assertEqual(r.status_code, 400)

    def test_no_photos(self):
        rid = self.reading_id(self.submit())
        r = self.c.get(f"/preview/{rid}")
        html = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 200)
        self.assertIn("did not upload a photo", html)
        self.assertIn("Moolank · Birth Number", html)
        self.assertIn("Love &amp; Relationships", html)
        self.assertNotIn("General Wellbeing</h2>", html)  # only chosen categories get an insight card
        self.assertEqual(self.c.get(f"/media/{rid}/face").status_code, 404)
        self.assertEqual(self.c.get(f"/media/{rid}/palm").status_code, 404)

    def test_face_only_and_palm_only_and_both(self):
        for kw in ({"face": True}, {"palm": True}, {"face": True, "palm": True}):
            rid = self.reading_id(self.submit(consent=True, **kw))
            rd = database.get_reading(rid)
            self.assertEqual(bool(rd["face_image"]), kw.get("face", False))
            self.assertEqual(bool(rd["palm_image"]), kw.get("palm", False))
            self.assertTrue(rd["photo_consent"] in (1, True))
            self.assertEqual(self.c.get(f"/preview/{rid}").status_code, 200)

    def test_consent_required_only_with_photo(self):
        r = self.submit(face=True, consent=False)
        self.assertEqual(r.status_code, 400)
        self.assertIn("tick the box", r.get_data(as_text=True))
        self.assertEqual(self.submit(consent=False).status_code, 302)   # no photo -> no consent needed

    def test_bad_uploads(self):
        data = {"csrf_token": self.token(), "name": "T", "gender": "Female", "dob": "1999-12-29", "categories": ["growth"],
                "photo_consent": "on", "palm_image": (io.BytesIO(b"not an image"), "palm.png")}
        r = self.c.post("/reading", data=data, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)
        self.assertIn("could not be read", r.get_data(as_text=True))
        data = {"csrf_token": self.token(), "name": "T", "gender": "Female", "dob": "1999-12-29", "categories": ["growth"],
                "photo_consent": "on", "palm_image": (io.BytesIO(b"x"), "evil.exe")}
        r = self.c.post("/reading", data=data, content_type="multipart/form-data")
        self.assertEqual(r.status_code, 400)
        self.assertIn("PNG, JPG, JPEG or WEBP", r.get_data(as_text=True))


class TestFlowAndReport(Base):
    def test_full_flow_and_categories(self):
        rid = self.reading_id(self.submit(categories=["love", "career"], mole_location="Chin"))
        self.assertEqual(self.c.get(f"/report/{rid}").status_code, 302)           # locked before payment
        self.assertEqual(self.c.get(f"/payment/{rid}").status_code, 200)
        self.assertIn("DEMO PAYMENT", self.c.get(f"/payment/{rid}").get_data(as_text=True))
        self.assertEqual(self.c.get(f"/demo-payment/{rid}").status_code, 302)
        r = self.c.get(f"/report/{rid}")
        html = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 200)
        self.assertIn("Love &amp; Relationships</h2>", html)
        self.assertIn("Career &amp; Professional Life</h2>", html)
        self.assertNotIn("Personal Growth</h2>", html)
        self.assertNotIn("General Wellbeing</h2>", html)
        self.assertIn("Not selected for this reading: Personal Growth, General Wellbeing", html)
        self.assertIn("1+6+0+7+2+0+0+2 = 18", html)
        self.assertIn("Mole Reading", html)
        self.assertIn("No photos were added", html)
        self.assertIn("Important disclaimer", html)
        self.assertNotIn("Photo-based reflection", html)

    def test_report_for_unknown_or_bad_id(self):
        self.assertEqual(self.c.get("/report/" + "0" * 32).status_code, 404)
        self.assertEqual(self.c.get("/preview/short").status_code, 404)

    def test_delete_photos_and_reading(self):
        rid = self.reading_id(self.submit(face=True, palm=True, consent=True))
        rd = database.get_reading(rid)
        f1, f2 = appmod.UPLOAD_DIR / rd["face_image"], appmod.UPLOAD_DIR / rd["palm_image"]
        self.assertTrue(f1.exists() and f2.exists())
        tok = self.token(f"/preview/{rid}")
        self.assertEqual(self.c.post(f"/reading/{rid}/delete-photos", data={"csrf_token": "bad"}).status_code, 400)
        self.assertEqual(self.c.post(f"/reading/{rid}/delete-photos", data={"csrf_token": tok}).status_code, 302)
        self.assertFalse(f1.exists() or f2.exists())
        self.assertIsNone(database.get_reading(rid)["face_image"])
        self.assertEqual(self.c.post(f"/reading/{rid}/delete", data={"csrf_token": tok}).status_code, 302)
        self.assertIsNone(database.get_reading(rid))

    def test_retention_purge(self):
        rid = self.reading_id(self.submit(face=True, consent=True))
        name = database.get_reading(rid)["face_image"]
        with database.get_connection() as conn:
            conn.execute("UPDATE readings SET created_at='2000-01-01T00:00:00' WHERE id=?", (rid,))
        self.assertGreaterEqual(appmod.purge_expired_photos(), 1)
        self.assertFalse((appmod.UPLOAD_DIR / name).exists())
        self.assertIsNone(database.get_reading(rid)["face_image"])
        self.assertEqual(self.c.get(f"/preview/{rid}").status_code, 200)   # reading text survives


class TestGemini(Base):
    def tearDown(self):
        os.environ.pop("GEMINI_API_KEY", None)
        sys.modules.pop("google", None)
        sys.modules.pop("google.genai", None)

    def fake_genai(self, behaviour):
        calls = []

        class Part:
            @staticmethod
            def from_bytes(data, mime_type):
                return ("img", len(data), mime_type)

        class Client:
            def __init__(self, api_key, http_options=None):
                self.models = self

            def generate_content(self, model, contents, config):
                calls.append(contents)
                if behaviour == "error":
                    raise RuntimeError("quota")
                return types.SimpleNamespace(text='{"reading": "Traditional face note.", "summary": "Warm summary."}')

        t = types.SimpleNamespace(Part=Part, HttpOptions=lambda timeout: None,
                                  GenerateContentConfig=lambda **kw: kw)
        google, genai = types.ModuleType("google"), types.ModuleType("google.genai")
        genai.Client, genai.types = Client, t
        google.genai = genai
        sys.modules["google"], sys.modules["google.genai"] = google, genai
        sys.modules["google.genai.types"] = t
        return calls

    def test_missing_key_does_not_crash(self):
        rid = self.reading_id(self.submit(face=True, consent=True))
        rd = database.get_reading(rid)
        self.assertFalse(rd["ai_analysis"]["ai_available"])
        self.assertEqual(rd["ai_analysis"]["face_status"], "unavailable")
        html = self.c.get(f"/preview/{rid}").get_data(as_text=True)
        self.assertIn("could not analyse", html)
        self.assertIn("Moolank", html)

    def test_no_photo_sends_nothing(self):
        os.environ["GEMINI_API_KEY"] = "k"
        calls = self.fake_genai("ok")
        self.reading_id(self.submit())
        self.assertEqual(calls, [])

    def test_success_one_request_per_photo(self):
        os.environ["GEMINI_API_KEY"] = "k"
        calls = self.fake_genai("ok")
        rid = self.reading_id(self.submit(face=True, palm=True, consent=True))
        self.assertEqual(len(calls), 2)
        joined = repr(calls)
        self.assertNotIn("Test User", joined)       # name is not sent
        self.assertNotIn("2002", joined)            # date of birth is not sent
        rd = database.get_reading(rid)
        self.assertTrue(rd["ai_analysis"]["ai_available"])
        self.c.get(f"/demo-payment/{rid}")
        html = self.c.get(f"/report/{rid}").get_data(as_text=True)
        self.assertIn("Photo-based reflection (AI-assisted)", html)
        self.assertIn("Traditional face note.", html)

    def test_gemini_error_is_graceful(self):
        os.environ["GEMINI_API_KEY"] = "k"
        self.fake_genai("error")
        rid = self.reading_id(self.submit(face=True, consent=True))
        rd = database.get_reading(rid)
        self.assertFalse(rd["ai_analysis"]["ai_available"])
        self.assertEqual(rd["ai_analysis"]["face_reading"], "")       # nothing invented
        self.c.get(f"/demo-payment/{rid}")
        html = self.c.get(f"/report/{rid}").get_data(as_text=True)
        self.assertNotIn("Photo-based reflection (AI-assisted)", html)
        self.assertIn("could not analyse", html)


class TestMigration(unittest.TestCase):
    def test_old_database_is_kept(self):
        old = TMP / "old.db"
        conn = sqlite3.connect(old)
        conn.executescript("""CREATE TABLE readings (id TEXT PRIMARY KEY, name TEXT NOT NULL, gender TEXT, dob TEXT, tob TEXT,
            pob TEXT, mole_location TEXT, face_image TEXT, palm_image TEXT, moolank INTEGER, bhagyank INTEGER,
            ai_analysis TEXT, paid INTEGER NOT NULL DEFAULT 0, created_at TEXT);
            INSERT INTO readings VALUES ('%s','Old User','Female','1999-12-29','','','Chin','a.jpg','b.jpg',2,6,
              '{"face_reading":"old face text","palm_reading":"old palm text","overall_ai_summary":"old","ai_available":true}',1,'2024-01-01T00:00:00');""" % ("a" * 32))
        conn.commit()
        conn.close()
        saved = database.DB_PATH
        database.DB_PATH = old
        try:
            database.init_db()
            database.init_db()  # idempotent
            rd = database.get_reading("a" * 32)
            self.assertEqual(rd["name"], "Old User")
            self.assertEqual(rd["categories"], [])
            self.assertTrue(rd["paid"])
            c = appmod.app.test_client()
            html = c.get("/report/" + "a" * 32).get_data(as_text=True)
            for t in ("Love &amp; Relationships</h2>", "Personal Growth</h2>", "Career &amp; Professional Life</h2>", "General Wellbeing</h2>"):
                self.assertIn(t, html)   # old records show all categories
            self.assertIn("old face text", html)
        finally:
            database.DB_PATH = saved


if __name__ == "__main__":
    unittest.main(verbosity=2)


class TestSafeUrl(unittest.TestCase):
    def test_only_http_links(self):
        self.assertEqual(appmod.safe_url("https://example.test/x"), "https://example.test/x")
        for bad in ("", "# a comment", "javascript:alert(1)", "example.com", 'https://a.test/"onclick="x'):
            self.assertEqual(appmod.safe_url(bad), "")
