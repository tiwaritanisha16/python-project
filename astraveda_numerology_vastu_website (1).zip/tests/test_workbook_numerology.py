"""Tests for numerology_core against the worked examples in Numerology_Numbers_and_Formulas.xls.
Expected values are taken from the workbook where its arithmetic is consistent, or worked out by hand from its rules
(documented in docs/DATA_IMPORT_REPORT.md) where the workbook's own example contains a slip."""
import sys
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import numerology_core as nc  # noqa: E402


class TestCore(unittest.TestCase):
    def test_reduce_and_masters(self):
        self.assertEqual(nc.reduce_number(29), 11)          # master kept
        self.assertEqual(nc.reduce_number(29, keep_master=False), 2)
        self.assertEqual(nc.reduce_number(10), 1)
        self.assertEqual(nc.reduce_number(44), 44 and 8)    # 4+4 = 8 (44 is not a master number here)
        self.assertEqual(nc.reduce_number(33), 33)
        self.assertEqual(nc.shown(11), "11/2")

    def test_life_path_workbook_example(self):
        self.assertEqual(nc.life_path(date(1982, 3, 23))["value"], 1)   # Sheet2 H9: 23-03-1982 -> 1
        self.assertEqual(nc.life_path(date(1992, 8, 15))["value"], 8)   # Sheet2 H71: 15/08/1992 -> 8
        self.assertEqual(nc.life_path(date(2009, 1, 1))["value"], 4)    # year 2009 -> 11 kept, 1+1+11 = 13 -> 4

    def test_birthday_attitude_karmic(self):
        self.assertEqual(nc.birthday_number(date(1982, 3, 23))["reduced"], 5)   # "Birthday Number: 23 (5)"
        self.assertEqual(nc.attitude_number(date(1982, 3, 23))["value"], 8)     # 23+3 = 26 -> 8
        self.assertIsNone(nc.karmic_check(date(1982, 3, 23))["value"])          # 26: free of karmic number (I48)
        self.assertEqual(nc.karmic_check(date(1990, 4, 9))["value"], 13)        # 9 + 4 = 13
        self.assertEqual(nc.karmic_check(date(1990, 9, 7))["value"], 16)

    def test_name_numbers_vidya_singh(self):
        self.assertEqual(nc.name_total("VIDYA SINGH", "pythagorean", "vowel")[0], 8)        # Sheet2 H19 -> 8
        self.assertEqual(nc.name_total("VIDYA SINGH", "pythagorean", "all")[0], 1)          # 7 + 3 = 10 -> 1 (workbook shows 11: slip)
        self.assertEqual(nc.name_total("VIDYA SINGH", "pythagorean", "consonant")[0], 11)   # 8 + 3 = 11 (workbook shows 3: slip)
        self.assertEqual(nc.growth_number("VIDYA SINGH", "pythagorean")["value"], 7)        # Sheet2 H36 -> 7
        self.assertEqual(nc.habit_challenge("VIDYA SINGH")["value"], 1)                     # Sheet2 H40 -> 1

    def test_vowel_rule_for_y(self):
        self.assertEqual(nc.vowel_flags("VIDYA"), [False, True, False, True, True])
        self.assertEqual(nc.vowel_flags("SINGH"), [False, True, False, False, False])

    def test_intensified_and_absent(self):
        r = nc.intensified_absent("VIDYA SINGH")
        self.assertEqual(r["freq"][1], 2)
        self.assertEqual(r["freq"][4], 2)
        self.assertEqual(r["absent"], [2, 3, 6])             # Sheet2 I33: "Absent Number: 2,3,6"
        self.assertEqual(r["intensified"], [1, 4, 7, 9])     # Sheet2 I30: all four tied numbers

    def test_maturity(self):
        # Sheet2 H44: Life Path 1 + Destiny 11 = 12 -> 3 (the rule, using the workbook's own inputs)
        self.assertEqual(nc.reduce_number(1 + 11), 3)

    def test_pinnacles_workbook_example(self):
        p = nc.pinnacles(date(1982, 3, 23), 1, 44)
        self.assertEqual([x["value"] for x in p], [8, 7, 6, 5])     # 4th: 3+2 = 5 (workbook shows 4: slip)
        self.assertEqual([x["age_text"] for x in p], ["age 0–35", "age 36–44", "age 45–53", "age 54+"])   # Sheet1 table, life path 1
        self.assertTrue(p[1]["current"])

    def test_challenges_workbook_example(self):
        c = nc.challenges(date(1992, 8, 15), 8, 34)
        self.assertEqual([x["value"] for x in c], [2, 3, 1, 5])      # Sheet2 H71
        self.assertTrue(c[1]["current"])                              # age 34 -> 2nd challenge

    def test_pinnacle_table_ages_follow_36_minus_life_path(self):
        for lp in range(1, 10):
            r = nc.PINNACLE_ROWS[lp]
            self.assertEqual(r["p1_end"], 36 - lp)
            self.assertEqual(r["p2_end"], r["p2_start"] + 8)
            self.assertEqual(r["p3_end"], r["p3_start"] + 8)

    def test_personal_cycles_workbook_example(self):
        c = nc.personal_cycles(date(1982, 3, 23), date(2026, 4, 8))
        self.assertEqual(c["personal_year"]["value"], 9)    # Sheet2 H52
        self.assertEqual(c["personal_month"]["value"], 4)   # Sheet2 H56
        self.assertEqual(c["personal_day"]["value"], 3)     # Sheet2 H60
        self.assertEqual(c["universal_year"]["value"], 1)   # 2+0+2+6 = 10 -> 1

    def test_essence_reproduces_whole_workbook_table(self):
        ex = nc.S1["essence_example"]
        self.assertEqual(len(ex["rows"]), 74)
        for i, row in enumerate(ex["rows"]):
            e = nc.essence("Devendra Prasad", 1970, 1970 + i)
            self.assertEqual((e["first_letter"], e["first_value"], e["last_letter"], e["last_value"]),
                             (row["first_letter"], row["first_value"], row["last_letter"], row["last_value"]), 1970 + i)
        self.assertEqual(nc.essence("Devendra Prasad", 1970, 2026)["value"], 5)     # M183 = 5
        self.assertEqual(nc.essence("Devendra Prasad", 1970, 1974)["value"], 3)     # 12 -> 3
        self.assertEqual(nc.essence("Devendra Prasad", 1970, 1970)["value"], 11)    # 11 kept as master

    def test_essence_needs_two_names(self):
        self.assertIsNone(nc.essence("Madonna", 1970, 2026))

    def test_transit_letters(self):
        self.assertEqual(nc.TRANSIT["A"][0], 1)
        self.assertEqual(nc.TRANSIT["R"][0], 9)
        self.assertEqual(nc.TRANSIT["Y"][0], 7)
        self.assertEqual(len(nc.TRANSIT), 26)

    def test_letter_tables_complete(self):
        for system in ("pythagorean", "chaldean"):
            self.assertEqual(sorted(nc.LETTER_VALUES[system]), [chr(c) for c in range(65, 91)], system)
        self.assertEqual(nc.letter_value("S", "chaldean"), 5)       # as printed in the workbook (see notes)

    def test_full_report_runs_for_edge_inputs(self):
        for name in ("Aarav Sharma", "Rao", "Anna-Maria O'Neil"):
            for dob in (date(1900, 1, 1), date(2000, 2, 29), date(2009, 11, 29)):
                for system in ("pythagorean", "chaldean"):
                    r = nc.full_report(name, dob, date(2026, 10, 13), system)
                    self.assertIn(r["life_path"]["value"], list(range(1, 10)) + [11, 22, 33])
                    self.assertEqual(len(r["pinnacles"]), 4)


if __name__ == "__main__":
    unittest.main()
