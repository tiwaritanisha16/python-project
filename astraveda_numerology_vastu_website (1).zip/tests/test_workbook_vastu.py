"""Vastu data tests: the JSON is compared with the original workbook cells, and the website tools are exercised."""
import os
import sys
import tempfile
import unittest
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("FLASK_SECRET_KEY", "test-secret")
import vastu  # noqa: E402

XLSX = ROOT / "docs" / "source_data" / "Vastu_Meter_ContentV1.xlsx"


class TestVastuData(unittest.TestCase):
    def test_all_sheets_and_elements(self):
        self.assertEqual(len(vastu.ELEMENTS), 33)
        by_sheet = {}
        for e in vastu.DATA["elements"]:
            by_sheet[e["sheet"]] = by_sheet.get(e["sheet"], 0) + 1
        self.assertEqual(by_sheet, {"vastucheck": 10, "utecbyultratech": 11, "Additional": 12})

    def test_every_cell_matches_the_workbook(self):
        wb = openpyxl.load_workbook(XLSX)
        checked = 0
        for e in vastu.DATA["elements"]:
            ws = wb[e["sheet"]]
            for code, d in e["directions"].items():
                name_c, label_c, score_c = [c.strip() for c in d["cells"].split(",")]
                self.assertEqual(ws[score_c].value, d["score"], (e["name"], code))
                raw = ws[label_c].value
                self.assertEqual(raw, d["label_raw"], (e["name"], code))
                checked += 1
        self.assertEqual(checked, 33 * 9)

    def test_brahmasthan_not_rated_everywhere(self):
        for e in vastu.DATA["elements"]:
            self.assertIsNone(e["directions"]["BR"]["score"], e["name"])
            self.assertIsNone(e["directions"]["BR"]["label"], e["name"])
            for code in vastu.RATED:
                self.assertIn(e["directions"][code]["score"], range(1, 11), (e["name"], code))

    def test_known_values(self):
        self.assertEqual(vastu.lookup("main-door", "NE")["score"], 10)
        self.assertEqual(vastu.lookup("main-door", "SW")["score"], 3)
        self.assertEqual(vastu.lookup("main-door", "SW")["label"], "Highly Inauspicious")
        self.assertEqual(vastu.lookup("kitchen", "SE")["score"], 10)
        self.assertEqual(vastu.lookup("kitchen", "NE")["label"], "Highly Inauspicious")
        self.assertEqual(vastu.lookup("staircase", "NE")["score"], 1)
        self.assertEqual(vastu.lookup("living-room", "SE")["score"], 10)
        self.assertEqual(vastu.lookup("septic-tank", "SW")["score"], 1)
        self.assertEqual(vastu.lookup("gym-workout-area", "SE")["score"], 8)
        self.assertEqual(vastu.lookup("house-in-plot", "SW")["score"], 10)
        self.assertIsNone(vastu.lookup("main-door", "XX"))
        self.assertIsNone(vastu.lookup("nothing", "NE"))

    def test_label_spellings_normalised(self):
        labels = {d["label"] for e in vastu.DATA["elements"] for d in e["directions"].values() if d["label"]}
        self.assertEqual(labels, {"Very Auspicious", "Highly Auspicious", "Auspicious", "Can Be Better", "Inauspicious", "Highly Inauspicious"})

    def test_grouping_covers_every_element_once(self):
        slugs = [e["slug"] for _, items in vastu.grouped() for e in items]
        self.assertEqual(sorted(slugs), sorted(vastu.ELEMENTS))


class TestMeter(unittest.TestCase):
    def test_average_and_rounding(self):
        r = vastu.meter({"main-door": "NE", "kitchen": "NE", "staircase": "N"})   # 10, 3, 1 -> 14/3 = 4.666..
        self.assertEqual([x["score"] for x in r["rows"]], [10, 3, 1])
        self.assertEqual(r["average"], 4.7)
        self.assertEqual(r["percent"], 47)

    def test_boundaries(self):
        r = vastu.meter({"septic-tank": "SW"})
        self.assertEqual(r["average"], 1.0)
        self.assertEqual(vastu.meter({"main-door": "NE"})["average"], 10.0)

    def test_invalid_and_unrated(self):
        r = vastu.meter({"main-door": "ZZ", "ghost-room": "NE", "pooja-room": "BR"})
        self.assertEqual(len(r["errors"]), 2)
        self.assertEqual(r["unrated"], ["Pooja Room"])
        self.assertIsNone(r["average"])
        self.assertEqual(vastu.meter({})["average"], None)

    def test_best_directions(self):
        row = vastu.meter({"kitchen": "NE"})["rows"][0]
        self.assertEqual(row["best_score"], 10)
        self.assertEqual(row["best_dirs"], ["SE"])


class TestVastuPages(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import database
        database.DB_PATH = Path(tempfile.mkdtemp()) / "v.db"
        import app as appmod
        database.init_db()
        appmod.app.config["TESTING"] = True
        cls.c = appmod.app.test_client()

    def test_every_room_page_opens(self):
        for slug in vastu.ELEMENTS:
            r = self.c.get(f"/vastu/guide/{slug}")
            self.assertEqual(r.status_code, 200, slug)
            self.assertIn("Highest rated", r.get_data(as_text=True))
        self.assertEqual(self.c.get("/vastu/guide/not-a-room").status_code, 404)

    def test_meter_page_result(self):
        r = self.c.get("/vastu/meter?go=1&main-door=NE&kitchen=SE&pooja-room=BR")
        html = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 200)
        self.assertIn("10.0", html)
        self.assertIn("Pooja Room", html)
        self.assertIn("no rating in the workbook", html)

    def test_meter_without_choice_is_friendly_error(self):
        r = self.c.get("/vastu/meter?go=1")
        self.assertEqual(r.status_code, 400)
        self.assertIn("at least one room", r.get_data(as_text=True))

    def test_meter_ignores_garbage(self):
        r = self.c.get("/vastu/meter?go=1&main-door=%3Cscript%3E&kitchen=SE")
        self.assertEqual(r.status_code, 200)
        self.assertNotIn("<script>", r.get_data(as_text=True))


class TestCalculatorPage(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import database
        database.DB_PATH = Path(tempfile.mkdtemp()) / "c.db"
        import app as appmod
        database.init_db()
        appmod.app.config["TESTING"] = True
        cls.c = appmod.app.test_client()

    def token(self):
        import re
        html = self.c.get("/numerology/calculator").get_data(as_text=True)
        return re.search(r'name="csrf_token" value="([0-9a-f]+)"', html).group(1)

    def post(self, **kw):
        data = {"csrf_token": self.token(), "name": "Vidya Singh", "dob": "1982-03-23", "as_of": "2026-04-08", "system": "pythagorean"}
        data.update(kw)
        return self.c.post("/numerology/calculator", data=data)

    def test_result_shown(self):
        r = self.post()
        html = r.get_data(as_text=True)
        self.assertEqual(r.status_code, 200)
        for text in ("Life Path Number", "Soul Urge Number", "Pinnacle numbers", "Challenge numbers", "Essence Number", "Personal Year", "age 0–35"):
            self.assertIn(text, html)

    def test_validation(self):
        for bad in ({"name": ""}, {"name": "12345"}, {"dob": ""}, {"dob": "2999-01-01"}, {"dob": "1800-01-01"}, {"as_of": "1900-01-01"}, {"as_of": "abc"}):
            r = self.post(**bad)
            self.assertEqual(r.status_code, 400, bad)

    def test_chaldean_and_single_name(self):
        self.assertEqual(self.post(system="chaldean").status_code, 200)
        r = self.post(name="Madonna")
        self.assertIn("needs both a first and a last name", r.get_data(as_text=True))

    def test_csrf_required(self):
        self.assertEqual(self.c.post("/numerology/calculator", data={"name": "A B", "dob": "1990-01-01"}).status_code, 400)

    def test_nothing_is_stored(self):
        import database
        before = len(list(database.get_connection().execute("SELECT id FROM readings")))
        self.post()
        after = len(list(database.get_connection().execute("SELECT id FROM readings")))
        self.assertEqual(before, after)


if __name__ == "__main__":
    unittest.main()
